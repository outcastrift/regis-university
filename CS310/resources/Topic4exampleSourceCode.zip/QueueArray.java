/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class QueueArray {
   String[] queueArray;
   int frontIdx;
   int rearIdx;
   int queueCount;
   int MAXSIZE=5;
   
   public QueueArray() {
      queueArray = new String[MAXSIZE];
      frontIdx = -1;  
      rearIdx = -1;
      queueCount = 0;
   }  
   
   
   private void addToQueue (String personName) {
      if (rearIdx > -1) {
         if (queueCount < MAXSIZE) {
            rearIdx++;
            if (rearIdx == MAXSIZE) {
               rearIdx = 0;
            } 
            queueArray[rearIdx] = personName;
            queueCount++;
         }
         else {
            System.out.println ("The queue is full");
         }
      } else {
         rearIdx = 0;
         frontIdx = 0;
         queueArray[rearIdx] = personName;
         queueCount++;
      }
   }
   
   private String removeFromQueue () {
      String personName = null;
      if (queueCount > 0) {
         personName = queueArray[frontIdx];
         queueCount--;
         if (queueCount > 0) {
            frontIdx++;
            if (frontIdx == MAXSIZE) {
               frontIdx = 0;
            }
         }
      } else {
         System.out.println ("The queue is empty");
      }
      return personName;
   }
   
   private boolean isEmpty() {
      boolean retValue = false;
      if (queueCount == 0) {
         retValue = true;
      }
      return (retValue);
   }
   
   private void printQueue() {
      if (!isEmpty()) {
         if (queueCount != 1) {
            System.out.println("The queue contains " + queueCount + " people");
         } else {
            System.out.println("The queue contains 1 person");       
         }
         System.out.println ("The front idx = " + frontIdx + " and the rear idx = " + rearIdx);
        
         boolean done = false;
         int idx = 0;
         int queueIdx = frontIdx;
         while (!done) {
            System.out.println ("node[" + idx++ + "] = " + queueArray[queueIdx] + ". Array location = " + queueIdx);
            if (queueIdx != rearIdx) {
               queueIdx++;
               if (queueIdx == MAXSIZE) {
                  queueIdx = 0;
               }
            } else {
               done = true;
            }
               
         }
         System.out.println();
      } else {
         System.out.println ("The queue is empty");
      }
   }
   public static void main(String[] args) {
      String personName;
      QueueArray queue = new QueueArray();
      queue.addToQueue("JOHN");
      queue.addToQueue("PAUL");
      queue.addToQueue("GEORGE");
      queue.addToQueue("RINGO");
      personName = queue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      
      queue.addToQueue("MARTIN");
      queue.addToQueue("ERIC");
      queue.addToQueue("MICKEY");
      queue.printQueue();

      personName = queue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      queue.printQueue();
      personName = queue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      queue.printQueue();
      personName = queue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      queue.printQueue();
      personName = queue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      queue.printQueue();
      personName = queue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      queue.printQueue();
      personName = queue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      queue.printQueue();
   }
   
}
