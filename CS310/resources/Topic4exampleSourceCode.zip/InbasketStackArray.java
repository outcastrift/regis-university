/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

import java.util.Calendar;

/**
 *
 * @author Mike
 */
public class InbasketStackArray {
   int[] inbasketStack;
   static int top;
   int MAXSIZE=6;
   
   public InbasketStackArray() {
      inbasketStack = new int[MAXSIZE];
      top = -1;  
   }  
   
   private void push (int paperNum) {
      if (top < inbasketStack.length) {
         top++;
         inbasketStack[top] = paperNum;
      }
      else {
         System.out.println ("The inbasket is full");
      }
   }
   
   private int pop () {
      int paperNum = -1;
   
      if (top > -1) {
         paperNum = inbasketStack[top];
         top--;
      }
      else {
         System.out.println ("the inbasket is empty");
      }
      return paperNum;
   }
   
   private boolean isEmpty() {
      boolean retValue = false;
      if (top < 0) {
         retValue = true;
      }
      return (retValue);
   }
   
   private void printStack() {
      if (!isEmpty()) {
         System.out.println("Inbasket contains " + (top + 1) + " papers");
         for (int idx = top;idx >= 0;idx--) {
            System.out.println ("element[" + idx + "] = " + inbasketStack[idx]);
         }
         System.out.println();
      } else {
         System.out.println ("Inbasket stack is empty");
      }
   }
   public static void main(String[] args) {
      long millisStart = Calendar.getInstance().getTimeInMillis() %1000000;
      System.out.println ("M=" + millisStart);

      int paperNum;
      InbasketStackArray inbasket = new InbasketStackArray();
      inbasket.push(101);
      inbasket.push(202);
      paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      inbasket.push(303);
      inbasket.push(404);
      paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      inbasket.printStack();
      if (inbasket.isEmpty()) {
         System.out.println ("The in-basket is now empty");
      }
   }
   
}
