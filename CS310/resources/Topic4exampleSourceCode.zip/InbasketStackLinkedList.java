/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class InbasketStackLinkedList {
   
   InbasketNode topNode;
   
   public InbasketStackLinkedList() {
      topNode = null;
   }
   
   public void push (int paperNum) {
     InbasketNode newNode = new InbasketNode(paperNum); 
     if (topNode != null) {
        newNode.setNextNode(topNode);
     }
     topNode = newNode;
   }
   
   private int pop () {
     int paperNum = -1;
     if (topNode != null) {
        paperNum = topNode.getPaperNum();
        topNode = topNode.getNextNode();
     } else {
        System.out.println("Stack was empty - cannot pop");
     }
      return paperNum;
   }
   
   private boolean isEmpty() {
      boolean retValue = false;
      if (topNode ==  null) {
         retValue = true;
      }
      return (retValue);
   }
   
   private int calculateNumberOfNodes() {
      int count = 0;
      InbasketNode currNode = topNode;
      while (currNode != null) {
         count++;
         currNode = currNode.getNextNode();
      }
      return count;
   }
   
   private void printStack() {
      if (!isEmpty()) {
         int count = 1;
         InbasketNode currNode = topNode;
         System.out.println("Inbasket contains " + calculateNumberOfNodes() + " papers");
         while (currNode != null) {
            System.out.println ("element[" + count + "] = " + currNode.getPaperNum());
            count++;
            currNode = currNode.getNextNode();
         }
         System.out.println();
      } else {
         System.out.println ("Inbasket stack is empty");
      }
   }
   public static void main(String[] args) {
      int paperNum;
      InbasketStackLinkedList inbasket = new InbasketStackLinkedList();
      inbasket.push(101);
      
      
      inbasket.push(202);
      inbasket.printStack();
      
  /*    paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      inbasket.printStack();
  /*    inbasket.push(303);
      inbasket.push(404);
      paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      paperNum = inbasket.pop();
      System.out.println ("You have taken paper #" + paperNum + " out of the in=basket");
      inbasket.printStack();
      if (inbasket.isEmpty()) {
         System.out.println ("The in-basket is now empty");
      }  */
   }
   
}
