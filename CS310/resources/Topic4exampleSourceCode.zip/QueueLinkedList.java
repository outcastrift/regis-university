
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class QueueLinkedList {
   
   QueueNode frontNode;
   QueueNode rearNode;
   
   public QueueLinkedList() {
      frontNode = null;
      rearNode = null;
   }
   
   public void addToQueue (String personName) {
     QueueNode newNode = new QueueNode(personName); 
     if (rearNode != null) {
        rearNode.setNextNode(newNode);
     } else {
        frontNode = newNode;
     }

     rearNode = newNode;
   }
   
   private String removeFromQueue () {
     String personName = null;
     if (frontNode != null) {
        personName = frontNode.getPersonName();
        frontNode = frontNode.getNextNode();
     } else {
        System.out.println("Queue was empty - cannot return person");
     }
      return personName;
   }
   
   private boolean isEmpty() {
      boolean retValue = false;
      if (frontNode ==  null) {
         retValue = true;
      }
      return (retValue);
   }
   
   private int calculateNumberOfNodes() {
      int count = 0;
      QueueNode currNode = frontNode;
      while (currNode != null) {
         count++;
         currNode = currNode.getNextNode();
      }
      return count;
   }
   
   private void printQueue() {
      if (!isEmpty()) {
         int count = 1;
         QueueNode currNode = frontNode;
         count = calculateNumberOfNodes();
         if (count > 1) {
            System.out.println("The queue contains " + count + " people");
         } else {
            System.out.println ("The queue contains 1 person");
         }
         count = 1;
         while (currNode != null) {
            System.out.println ("node[" + count + "] = " + currNode.getPersonName());
            count++;
            currNode = currNode.getNextNode();
         }
         System.out.println();
      } else {
         System.out.println ("Queue is empty");
      }
   }
   public static void main(String[] args) {
      String personName;
      QueueLinkedList personQueue = new QueueLinkedList();
      personQueue.addToQueue("John");
      personQueue.addToQueue("Paul");
      personQueue.addToQueue("George");
      personQueue.addToQueue("Ringo");
      personName = personQueue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
      personQueue.addToQueue("Martin");
       personName = personQueue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
            personQueue.printQueue();

       personName = personQueue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
            personQueue.printQueue();

       personName = personQueue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
            personQueue.printQueue();

       personName = personQueue.removeFromQueue();
      System.out.println (personName + " was removed from the queue.");
            personQueue.printQueue();

       personName = personQueue.removeFromQueue();
      
    
   }
   
}
