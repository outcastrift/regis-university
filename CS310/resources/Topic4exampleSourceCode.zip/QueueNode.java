
package com.cs310.model.domain;

public class QueueNode {
   private String personName;
   private QueueNode nextNode;
   
   public QueueNode() {
      personName = null;
      nextNode = null;
   }
   
   public QueueNode(String personName) {
      this.personName = personName;
      this.nextNode = null;
   }

   public QueueNode getNextNode() {
      return nextNode;
   }

   public void setNextNode(QueueNode nextNode) {
      this.nextNode = nextNode;
   }

   public String getPersonName() {
      return personName;
   }

   public void setPersonName(String personName) {
      this.personName = personName;
   }
   
 }

