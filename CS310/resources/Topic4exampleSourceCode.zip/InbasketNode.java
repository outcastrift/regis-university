/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

public class InbasketNode {
   private int paperNum;
   private InbasketNode nextNode;
   
   public InbasketNode() {
      paperNum = 0;
      nextNode = null;
   }
   
   public InbasketNode(int paperNum) {
      this.paperNum = paperNum;
      this.nextNode = null;
   }

   public int getPaperNum() {
      return paperNum;
   }

   public void setPaperNum(int paperNum) {
      this.paperNum = paperNum;
   }

   public InbasketNode getNextNode() {
      return nextNode;
   }

   public void setNextNode(InbasketNode nextNode) {
      this.nextNode = nextNode;
   }
   
 }

