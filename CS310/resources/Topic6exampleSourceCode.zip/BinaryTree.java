/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

import java.util.Arrays;

/**
 *
 * @author Mike
 */
public class BinaryTree {
  
   TreeNode root;
   Car[] carArray;
   int carIdx;
   int numNodes;

   public BinaryTree() {
      this.carArray = null;
      this.carIdx = 0;
      this.root = null;
      int numNodes = 0;
   }

   public int getNumNodes() {
      return numNodes;
   }

   public void setNumNodes(int numNodes) {
      this.numNodes = numNodes;
   }

   public TreeNode getRoot() {
      return root;
   }

   public void setRoot(TreeNode root) {
      this.root = root;
   }


   public Car[] getCarArray() {
      return carArray;
   }

   public void setCarArray(Car[] carArray) {
      this.carArray = carArray;
   }

   public int getCarIdx() {
      return carIdx;
   }

   public void setCarIdx(int carIdx) {
      this.carIdx = carIdx;
   }
   
   public void insertIntoTree (TreeNode currNode,Car car) {
      if (currNode != null) {
         if (currNode.getCar().getModel().compareTo(car.getModel()) > 0) {    //less than root
            if (currNode.getLeftNode() != null) { 
               insertIntoTree(currNode.getLeftNode(),car);
            } else {
               TreeNode newNode = new TreeNode(car);
               currNode.setLeftNode(newNode);   
            }
         } if (currNode.getCar().getModel().compareTo(car.getModel()) < 0) {
            if (currNode.getRightNode() != null) {
               insertIntoTree(currNode.getRightNode(),car);
            } else {
               TreeNode newNode = new TreeNode(car);
               currNode.setRightNode(newNode);
            }
         }  
      } else {
         TreeNode newNode = new TreeNode(car);
         this.setRoot(newNode);
      }
   }
   
   public void rebuildTree(Car[] carArray) {
         
      int midPoint = carArray.length / 2;

      insertIntoTree (this.getRoot(),carArray[midPoint]);
      printTree(root);
      Car[] leftArray = new Car[midPoint];
      if (leftArray.length > 0) {
         for (int idx = 0;idx < leftArray.length;idx++) {
            leftArray[idx] = carArray[idx];
         }

         rebuildTree(leftArray);

         Car[] rightArray = new Car[(carArray.length )-(midPoint+1)];
         if (rightArray.length > 0) {
            int idx1 = 0;
            for (int idx = midPoint+1;idx <  carArray.length;idx++) {
               rightArray[idx1] = carArray[idx];
               idx1++;
            }

            rebuildTree(rightArray);
         }
      }
   }
   
   public boolean isTreeBalanced(TreeNode currNode) {
   boolean retval = false;
   if (currNode == null) {
      retval = true;
   } else if (getTreeHeight(currNode) != -1){
      retval = true;
   }
   return retval;
}
 
   public int getTreeHeight(TreeNode currNode) {
      int retval = 0;
      if (currNode != null) {
         int leftNode = getTreeHeight(currNode.getLeftNode());
         int rightNode = getTreeHeight(currNode.getRightNode());

         if (leftNode == -1 || rightNode == -1) {
            retval = -1;
         } else if (Math.abs(leftNode - rightNode) > 1) {
        retval = -1;
         } else {
           retval = Math.max(leftNode, rightNode) + 1;
         }
      }
      return retval;
   }

   private int getNodeCount (TreeNode currNode)
   {
     if (currNode != null) {
        numNodes++;
        getNodeCount (currNode.getLeftNode());
        getNodeCount (currNode.getRightNode());
     }
     return numNodes;
   }
   
   void dumpTree (TreeNode currNode)
   { 
     if (currNode != null) {
        dumpTree (currNode.getLeftNode());
        carArray[carIdx++] = currNode.getCar();
        dumpTree (currNode.getRightNode());
     }
   }
   
   private void printTree(TreeNode currNode) {
      if (currNode == null) return;

      printTree(currNode.getLeftNode());
      System.out.print(currNode.getCar().getModel() + "  ");
      printTree(currNode.getRightNode());
     }

   
   public void add (Object obj) {
      Car car = (Car)obj;
      insertIntoTree (root,car);
      if (!(isTreeBalanced(root))) {
         carArray = new Car[getNodeCount(root)];
         carIdx = 0;
         dumpTree(root);
         this.setRoot(null);
         rebuildTree(carArray);
      }
   }
   
   
   private boolean doesTreeContain (TreeNode currNode,Car car) {
      boolean retVal = false;
      if (currNode.getCar().getModel().compareTo(car.getModel()) == 0) {
         retVal = true;
      }
      else 
      {
         if (currNode.getCar().getModel().compareTo(car.getModel()) > 0) { 
            if (currNode.getLeftNode() != null) { 
               doesTreeContain(currNode.getLeftNode(),car);
            }
         }
         if (currNode.getCar().getModel().compareTo(car.getModel()) < 0) { 
            if (currNode.getRightNode() != null) { 
               doesTreeContain(currNode.getRightNode(),car);
            }
         }
      }
      return (retVal);
   }
   
   
   public boolean contains(Object obj) {
      Car car = (Car)obj;
      return doesTreeContain(root,car);
   }

   
   public boolean isEmpty() {
      return (root == null);
   }

   
   public int structSize() {
      return (getNodeCount(root));
   }
   
   public static void main(String[] args) {

      BinaryTree bt = new BinaryTree();
      Car car = new Car("1","Dodge","Magnum","5.7");
      bt.insertIntoTree(bt.getRoot(), car);
  
      System.out.println ("___________________________________");
      car = new Car("2","Toyota","Versa","1.0");
      bt.insertIntoTree(bt.getRoot(), car);
      bt.printTree(bt.getRoot());
      System.out.println ("___________________________________");
      
      car = new Car("4","Ford","Mustang","4.6");
      bt.insertIntoTree(bt.getRoot(), car);
      bt.printTree(bt.getRoot());
      System.out.println ("___________________________________");
      
      car = new Car("5","Dodge","Dart","3.7");
      bt.insertIntoTree(bt.getRoot(), car);
      bt.printTree(bt.getRoot());
      System.out.println ("___________________________________");
      
      car = new Car("6","Lexus","ES350","3.7");
      bt.insertIntoTree(bt.getRoot(), car);
      bt.printTree(bt.getRoot());
      System.out.println ("___________________________________");
      
      car = new Car("99","Ford ","Focus","3.7");
      bt.insertIntoTree(bt.getRoot(), car);
      bt.printTree(bt.getRoot());
      
      car = new Car("98","Nissan ","Xterra","3.7");
      bt.insertIntoTree(bt.getRoot(), car);
      bt.printTree(bt.getRoot());
      System.out.println ("___________________________________");
      
      car = new Car("97","Ford ","Explorer","3.7");
      bt.insertIntoTree(bt.getRoot(), car);
      bt.printTree(bt.getRoot());
      System.out.println();
      System.out.println ("___________________________________");
      
      System.out.println ("root = " + bt.getRoot().getCar().getModel());
      bt.setNumNodes(0);
      System.out.println ("node count "  + bt.getNodeCount(bt.getRoot()));
      
      if (bt.isTreeBalanced(bt.getRoot())) {
         System.out.println ("tree is balanced");
      }
         else System.out.println("tree is not balanced");
      
      bt.setNumNodes(0);
      Car[] newArray = new Car[bt.getNodeCount(bt.getRoot())];
      bt.setCarArray(newArray);
      bt.setCarIdx(0);
      bt.dumpTree(bt.getRoot());

      System.out.println("getting ready to rebuild");
      bt.setRoot(null);
      bt.rebuildTree(bt.getCarArray());
      
      if (bt.isTreeBalanced(bt.getRoot())) {
         System.out.println ("tree is balanced");
      }
         else System.out.println("tree is not balanced");
      
   }
}
