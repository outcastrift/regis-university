/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class TreeNode {
   Car car;
   TreeNode leftNode;
   TreeNode rightNode;

   public TreeNode() {
      this.car = null;
      this.leftNode = null;
      this.rightNode = null;
   }

   public TreeNode(Car car) {
      this.car = car;
      this.leftNode = null;
      this.rightNode = null;
   }

   public Car getCar() {
      return car;
   }

   public void setCar(Car car) {
      this.car = car;
   }

   public TreeNode getLeftNode() {
      return leftNode;
   }

   public void setLeftNode(TreeNode leftNode) {
      this.leftNode = leftNode;
   }

   public TreeNode getRightNode() {
      return rightNode;
   }

   public void setRightNode(TreeNode rightNode) {
      this.rightNode = rightNode;
   }
}
