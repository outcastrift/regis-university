/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class VisitorMapEntry {
   private int key;
   private Visitor value;

   public VisitorMapEntry(int key, Visitor value) {
      this.key = key;
      this.value = value;
   }

   public int getKey() {
      return key;
   }

   public void setKey(int key) {
      this.key = key;
   }

   public Visitor getValue() {
      return value;
   }

   public void setValue(Visitor value) {
      this.value = value;
   }
   
   
}

