/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class PersonChainHashSetImpl  {
   private int MAXSIZE;
   private int currSize;
   private int numIdx;
   private PersonNode[] personHashSet;
   
   public PersonChainHashSetImpl() {
      MAXSIZE = 10;
      currSize = 0;
      numIdx = 0;
      personHashSet = new PersonNode[MAXSIZE];
      for (int idx = 0;idx < personHashSet.length;idx++) {
         personHashSet[idx] = null;
      }
   }
   
   
   public void add(Object obj) {
      Person person = (Person)obj;
      System.out.println ("Person being added is " + person.getLastName());

      PersonNode newNode = new PersonNode(person);
      int hashCode = person.hashCode() % MAXSIZE;
      if (personHashSet[hashCode] == null) {
         currSize++;
         numIdx++;
         personHashSet[hashCode] = newNode;
      }
      else
      {
         for (PersonNode currNode = personHashSet[hashCode];currNode != null;currNode = currNode.getNextNode()) {
            if (currNode.getNextNode() == null) {
               currNode.setNextNode(newNode);
               numIdx++;
               break;
            }
         }
      }
   }

   
   public void remove(Object obj) {
      Person person = (Person)obj;
      System.out.println ("Person being removed is " + person.getLastName());
      PersonNode newNode = new PersonNode(person);
      int hashCode = person.hashCode() % MAXSIZE;
      if (personHashSet[hashCode] != null) {
         if (personHashSet[hashCode].getNextNode() == null) {
            currSize--;
            numIdx--;
            personHashSet[hashCode] = null;
         }
         else
         {
            PersonNode prevNode = null;
            for (PersonNode currNode = personHashSet[hashCode];currNode != null;prevNode = currNode,currNode = currNode.getNextNode()) {
               System.out.println("currNode = " + currNode.getPerson().getLastName());
               if (currNode.getPerson().getFirstName().equals(person.getFirstName())) {               
                  numIdx--;
                  if (prevNode != null) {
                     prevNode.setNextNode(currNode.getNextNode());
                  } else {
                     personHashSet[hashCode] = currNode.getNextNode();
                  }
                  break;
               }
            }
         }
      }
      
   }
   
  
    public void printHash() {
      System.out.println ("Current size = " + currSize + " Number of Elements = " + numIdx);
      for (int idx = 0;idx < personHashSet.length;idx++) {
         if (personHashSet[idx] != null) {
            System.out.println("   Index = " + idx);
            for (PersonNode currNode = personHashSet[idx];currNode != null;currNode = currNode.getNextNode()) {
               System.out.println ("      Last Name = " + currNode.getPerson().getLastName());
            }
         }
      }
      System.out.println();
   }
    
    public static void main(String[] args) {
      PersonChainHashSetImpl hash = new PersonChainHashSetImpl();
      Person person = new Person("Barack","Obama","000-00-9998","1600 Pennsylvania St","Washington DC");
      hash.add(person);
      hash.printHash();
      person = new Person("George","Washington","000-00-0001","Mount Vernon","Virgina");
      hash.add(person);
      hash.printHash();
      person = new Person("Abe","Lincoln","000-00-0016","Springfield","Illinois");
      hash.add(person);
      hash.printHash();
      person = new Person("Barack","Obama2","000-00-9998","1600 Pennsylvania St","Washington DC");
      hash.add(person);
      hash.printHash();
      person = new Person("Barack","Obama","000-00-9998","1600 Pennsylvania St","Washington DC");
      hash.remove(person);
      hash.printHash();
      
      }
   
}
