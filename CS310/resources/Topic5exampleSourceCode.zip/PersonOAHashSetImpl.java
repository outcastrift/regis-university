/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class PersonOAHashSetImpl  {
   private int MAXSIZE;
   private int currSize;
   private Person[] personHashSet;

   public PersonOAHashSetImpl() {
      MAXSIZE = 10;
      currSize = 0;
      personHashSet = new Person[MAXSIZE];
      for (int idx = 0;idx < personHashSet.length;idx++) {
         personHashSet[idx] = null;
      }
   }

   
   public void add(Object obj) {
      boolean found = false;
      Person person = (Person)obj;
      int hashCode = person.hashCode() % MAXSIZE;
      System.out.println("hashCode = " + hashCode);
      while (!found) {
         if (personHashSet[hashCode] == null) {
            personHashSet[hashCode] = person;
            currSize++;
            found = true;
            System.out.println("Person " + person.getLastName() + " added.");
         }
         else {
            hashCode++;
            if (hashCode > personHashSet.length) {
               hashCode = 0;
            }
         }
      }
   }

   
   public void remove(Object obj) {
      boolean found = false;
      Person person = (Person)obj;
      int hashCode = person.hashCode() % MAXSIZE;
      System.out.println("hashCode = " + hashCode);

      while (!found) {
         if (personHashSet[hashCode].equals(person)) {
            personHashSet[hashCode] = null;
            currSize--;
            found = true;
            System.out.println("Person " + person.getLastName() + " removed.");
         }
         else {
            hashCode++;
            if (hashCode > personHashSet.length) {
               hashCode = 0;
            }
         }
      }
   }

   
   public boolean contains(Object obj) {
      boolean found = false;
      Person person = (Person)obj;
      int hashCode = person.hashCode() % MAXSIZE;
      while (!found) {
         if (personHashSet[hashCode].equals(person)) {
            found = true;
         }
         else {
            hashCode++;
            if (hashCode > personHashSet.length) {
               hashCode = 0;
            }
         }
      }
      return found;
   }

   
   public boolean isEmpty() {
      boolean retValue = false;
      if (currSize == 0) {
         retValue = true;
      }
      return retValue;
   }

   
   public int structSize() {
      return currSize;
   }
   
   public void printHash() {

      for (int idx = 0;idx < personHashSet.length;idx++) {
         if (personHashSet[idx] != null) {
            System.out.println("Index = " + idx + " Last Name = " + personHashSet[idx].getLastName());
         }
      }
      System.out.println();
   }
   
   public static void main(String[] args) {
      PersonOAHashSetImpl hash = new PersonOAHashSetImpl();
      Person person = new Person("Barack","Obama","000-00-9998","1600 Pennsylvania St","Washington DC");
      hash.add(person);
      hash.printHash();
      person = new Person("George","Washington","000-00-0001","Mount Vernon","Virgina");
      hash.add(person);
      hash.printHash();
      person = new Person("Abe","Lincoln","000-00-0016","Springfield","Illinois");
      hash.add(person);
      hash.printHash();
      person = new Person("Barack","Obama2","000-00-9998","1600 Pennsylvania St","Washington DC");
      hash.add(person);
      hash.printHash();
      boolean retValue = hash.contains (person);
      if (retValue) {
         System.out.println ("Hash set contains " + person.getLastName());
         System.out.println();
      }
      hash.remove(person);
      hash.printHash();
      
      
   }
}
