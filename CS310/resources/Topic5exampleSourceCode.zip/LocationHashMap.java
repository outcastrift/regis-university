/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class LocationHashMap {
   private final int MAXSIZE;
   private int currSize;
   LocationMapEntry locationHashMap[];

   public LocationHashMap() {
      MAXSIZE = 100;
      currSize = 0;
      locationHashMap = new LocationMapEntry[MAXSIZE];
      for (int idx = 0;idx < locationHashMap.length;idx++) {
         locationHashMap[idx] = null;
      }
   }
   
   
   public void add(Object obj) {
      boolean found = false;
      Location location = (Location) obj;
      System.out.println ("Location being added is " + location.getOfficeName());

      int hashCode = location.hashCode() % MAXSIZE;
      LocationMapEntry newLocation = new LocationMapEntry(hashCode,location);
      while (!found) {
         if (locationHashMap[hashCode] == null) {
            locationHashMap[hashCode] = newLocation;
            currSize++;
            found = true;
            System.out.println("Location " + location.getOfficeName() + " added.");
         }
         else {
            hashCode++;
            if (hashCode > locationHashMap.length) {
               hashCode = 0;
            }
         }
      }
   }

   
   public void remove(Object obj) {
      boolean found = false;
      Location location = (Location)obj;
      int hashCode = location.hashCode() % MAXSIZE;
      System.out.println("hashCode = " + hashCode);

      while (!found) {
         if (locationHashMap[hashCode].getValue().equals(location)) {
            locationHashMap[hashCode] = null;
            currSize--;
            found = true;
            System.out.println("Location " + location.getOfficeName() + " removed.");
         }
         else {
            hashCode++;
            if (hashCode > locationHashMap.length) {
               hashCode = 0;
            }
         }
      } 
   }
   
   public void remove(int hashCode) {
      boolean found = false;
     
      while (!found) {
         if (locationHashMap[hashCode].getKey() == hashCode) {
            locationHashMap[hashCode] = null;
            currSize--;
            found = true;
         }
         else {
            hashCode++;
            if (hashCode > locationHashMap.length) {
               hashCode = 0;
            }
         }
      } 
   }

  
   public boolean contains(Object obj) {
      boolean found = false;
      Location location = (Location)obj;
      int hashCode = location.hashCode() % MAXSIZE;
      System.out.println("hashCode = " + hashCode);

      while (!found) {
         if (locationHashMap[hashCode].getValue().equals(location)) {
            found = true;
         }
         else {
            hashCode++;
            if (hashCode > locationHashMap.length) {
               hashCode = 0;
            }
         }
      } 
      return (found);
   }

  
   public boolean isEmpty() {
      boolean retValue = false;
      if (currSize == 0) {
         retValue = true;
      }
      return (retValue);
   }

   
   public int structSize() {
     return currSize;
   }
   
   public Location getLocationByKey (int hashCode) {
      boolean found = false;
      Location location = null;
      
      while (!found) {
         if (locationHashMap[hashCode].getKey() == hashCode) {
            location = locationHashMap[hashCode].getValue();
            found = true;
            System.out.println("Location " + location.getOfficeName() + " found.");
         }
         else {
            hashCode++;
            if (hashCode > locationHashMap.length) {
               hashCode = 0;
            }
         }
      } 
      return location;
   }
   
    public void printMap() {
      for (LocationMapEntry me : locationHashMap) {
         if (me != null) {
            System.out.println ("hashcode key = " + me.getKey());
            System.out.println ("Location office = " + me.getValue().getOfficeName());
            System.out.println ("Location City = " + me.getValue().getCity());
            System.out.println ("Location Zip  = " + me.getValue().getZipCodePlus4());
            System.out.println();
         }
      }
      System.out.println("------------------------------------------------");
   }
}

