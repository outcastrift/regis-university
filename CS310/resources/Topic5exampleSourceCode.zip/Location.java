/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

import java.util.Objects;

/**
 *
 * @author Mike
 */
public class Location {
   private String officeName;
   private String city;
   private String zipCodePlus4;

   public Location() {
   }

   public Location(String officeName, String city, String zipCodePlus4) {
      this.officeName = officeName;
      this.city = city;
      this.zipCodePlus4 = zipCodePlus4;
   }

   public String getOfficeName() {
      return officeName;
   }

   public void setOfficeName(String officeName) {
      this.officeName = officeName;
   }

   public String getCity() {
      return city;
   }

   public void setCity(String city) {
      this.city = city;
   }

   public String getZipCodePlus4() {
      return zipCodePlus4;
   }

   public void setZipCodePlus4(String zipCodePlus4) {
      this.zipCodePlus4 = zipCodePlus4;
   }

   @Override
   public int hashCode() {
      int hashCode = 0;
      for (char c : this.zipCodePlus4.toCharArray()){ 
         int inc = (int)(c);
         hashCode = hashCode + inc;
      }
      return  hashCode;
   }

   @Override
   public boolean equals(Object obj) {
      if (obj == null) {
         return false;
      }
      if (getClass() != obj.getClass()) {
         return false;
      }
      final Location other = (Location) obj;
      if (!Objects.equals(this.officeName, other.officeName)) {
         return false;
      }
      if (!Objects.equals(this.city, other.city)) {
         return false;
      }
      if (!Objects.equals(this.zipCodePlus4, other.zipCodePlus4)) {
         return false;
      }
      return true;
   }
   
   
}

