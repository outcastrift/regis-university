/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class VisitTest {
  
   public VisitTest() {}

   public static void main(String[] args) {
      Visit visitArray[] = new Visit[3];
      VisitorHashMap visitorMap = new VisitorHashMap();
      LocationHashMap locationMap = new LocationHashMap();
     // populate maps  
      
      Visitor visitor = new Visitor("George Washington","2025555555","George@Washington.com");
      visitorMap.add(visitor);
      visitor = new Visitor("Abraham Lincoln","4045555555","Abraham@Lincoln.com");
      visitorMap.add(visitor);
      visitor = new Visitor("Barack Obama","3035555555","Barack@Obama.com");
      visitorMap.add(visitor);
      visitor = new Visitor("Benedict Arnold","6065555555","Benedict@Arnold.com");
      visitorMap.add(visitor);
      
      Location location = new Location ("California","Beverly Hills","901200001");
      locationMap.add(location);
      location = new Location ("Statue of Liberty","Liberty Island","100040011");
      locationMap.add(location);
      location = new Location ("Headquarters","Schenectady","123451010");
      locationMap.add(location);
      location = new Location ("Vulture Central","Death Valley","923289876");
      locationMap.add(location);

      visitorMap.remove(visitor);  // current visitor is Benedict Arnold
      locationMap.remove(86);  // removing by hashcode key
      
      Visit visit = new Visit(39,45,"07/04/1776","Thomas Jefferson","discuss documents");
      visitArray[0] = visit;
      visit = new Visit(43,49,"11/19/1863","Ulysses S. Grant","give a speech");
      visitArray[1] = visit;
      visit = new Visit(41,39,"09/01/2013","Chris Christie","assess storm damage");
      visitArray[2] = visit;
      
 
      for (int idx = 0;idx < 3; idx++) {
         visit = visitArray[idx];
         int visitorKey = visit.getVisitorKey();
         visitor = visitorMap.getVisitorByKey(visitorKey);
         int locationKey = visit.getLocationKey();
         location = locationMap.getLocationByKey(locationKey);
         
         System.out.println("VISIT #" + (idx+1));
         System.out.println ("   Date of visit    = " + visit.getDateOfVisit());
         System.out.println ("   Person visited   = " + visit.getPersonVisited());
         System.out.println ("   Purpose of visit = " + visit.getPurposeOfVisit());
         System.out.println("VISITOR");
         System.out.println ("   Visitor name = " + visitor.getVisitorName());
         System.out.println ("   Visitor phone = " + visitor.getVisitorPhone());
         System.out.println ("   Visitor email = " + visitor.getVisitorEmail());
         System.out.println("LOCATION");
         System.out.println ("   Location name  = " + location.getOfficeName());
         System.out.println ("   Location city  = " + location.getCity());
         System.out.println ("   Location zip  = " + location.getZipCodePlus4());
         System.out.println("-----------------------------------------------");
      }
      
   }
   
}
