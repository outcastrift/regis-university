/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class Visit {
   private int visitorKey;
   private int locationKey;
   private String dateOfVisit;
   private String personVisited;
   private String purposeOfVisit;
   
   public Visit() {
   }
   
   public Visit(int visitorKey, int locationKey, String dateOfVisit, String personVisited, String purposeOfVisit) {
      this.visitorKey = visitorKey;
      this.locationKey = locationKey;
      this.dateOfVisit = dateOfVisit;
      this.personVisited = personVisited;
      this.purposeOfVisit = purposeOfVisit;
   }

   public int getVisitorKey() {
      return visitorKey;
   }

   public void setVisitorKey(int visitorKey) {
      this.visitorKey = visitorKey;
   }

   public int getLocationKey() {
      return locationKey;
   }

   public void setLocationKey(int locationKey) {
      this.locationKey = locationKey;
   }

   public String getDateOfVisit() {
      return dateOfVisit;
   }

   public void setDateOfVisit(String dateOfVisit) {
      this.dateOfVisit = dateOfVisit;
   }

   public String getPersonVisited() {
      return personVisited;
   }

   public void setPersonVisited(String personVisited) {
      this.personVisited = personVisited;
   }

   public String getPurposeOfVisit() {
      return purposeOfVisit;
   }

   public void setPurposeOfVisit(String purposeOfVisit) {
      this.purposeOfVisit = purposeOfVisit;
   } 
}


