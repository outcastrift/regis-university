/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

/**
 *
 * @author Mike
 */
public class VisitorHashMap  {
   private final int MAXSIZE;
   private int currSize;
   VisitorMapEntry visitorHashMap[];

   public VisitorHashMap() {
      MAXSIZE = 100;
      currSize = 0;
      visitorHashMap = new VisitorMapEntry[MAXSIZE];
      for (int idx = 0;idx < visitorHashMap.length;idx++) {
         visitorHashMap[idx] = null;
      }
   }
   
   
   public void add(Object obj) {
      boolean found = false;
      Visitor visitor = (Visitor) obj;
      System.out.println ("Visitor being added is " + visitor.getVisitorName());

      int hashCode = visitor.hashCode() % MAXSIZE;
      VisitorMapEntry newVisitor = new VisitorMapEntry(hashCode,visitor);
      while (!found) {
         if (visitorHashMap[hashCode] == null) {
            visitorHashMap[hashCode] = newVisitor;
            currSize++;
            found = true;
            System.out.println("Visitor " + visitor.getVisitorName() + " added.");
         }
         else {
            hashCode++;
            if (hashCode > visitorHashMap.length) {
               hashCode = 0;
            }
         }
      }
   }

   
   public void remove(Object obj) {
      boolean found = false;
      Visitor visitor = (Visitor)obj;
      int hashCode = visitor.hashCode() % MAXSIZE;
      System.out.println("hashCode = " + hashCode);

      while (!found) {
         if (visitorHashMap[hashCode].getValue().equals(visitor)) {
            visitorHashMap[hashCode] = null;
            currSize--;
            found = true;
            System.out.println("Visitor " + visitor.getVisitorName() + " removed.");
         }
         else {
            hashCode++;
            if (hashCode > visitorHashMap.length) {
               hashCode = 0;
            }
         }
      } 
   }
   
   public void remove(int hashCode) {
      boolean found = false;
     
      while (!found) {
         if (visitorHashMap[hashCode].getKey() == hashCode) {
            visitorHashMap[hashCode] = null;
            currSize--;
            found = true;
         }
         else {
            hashCode++;
            if (hashCode > visitorHashMap.length) {
               hashCode = 0;
            }
         }
      } 
   }

   
   public boolean contains(Object obj) {
      boolean found = false;
      Visitor visitor = (Visitor)obj;
      int hashCode = visitor.hashCode() % MAXSIZE;
      System.out.println("hashCode = " + hashCode);

      while (!found) {
         if (visitorHashMap[hashCode].getValue().equals(visitor)) {
            found = true;
         }
         else {
            hashCode++;
            if (hashCode > visitorHashMap.length) {
               hashCode = 0;
            }
         }
      } 
      return (found);
   }
   
   public boolean contains(int hashCode) {
      boolean found = false;

      while (!found) {
         if (visitorHashMap[hashCode].getKey() == hashCode) {
            found = true;
         }
         else {
            hashCode++;
            if (hashCode > visitorHashMap.length) {
               hashCode = 0;
            }
         }
      } 
      return (found);
   }

   
   public boolean isEmpty() {
      boolean retValue = false;
      if (currSize == 0) {
         retValue = true;
      }
      return (retValue);
   }

   
   public int structSize() {
     return currSize;
   }
   
   public Visitor getVisitorByKey (int hashCode) {
      boolean found = false;
      Visitor visitor = null;
      
      while (!found) {
         if (visitorHashMap[hashCode].getKey() == hashCode) {
            visitor = visitorHashMap[hashCode].getValue();
            found = true;
            System.out.println("Visitor " + visitor.getVisitorName() + " found.");
         }
         else {
            hashCode++;
            if (hashCode > visitorHashMap.length) {
               hashCode = 0;
            }
         }
      } 
      return visitor;
   }
   
   public void printMap() {
      for (int idx = 0;idx < visitorHashMap.length;idx++) {
         if (visitorHashMap[idx] != null) {
            VisitorMapEntry me = visitorHashMap[idx];
            System.out.println ("hashcode key = " + me.getKey());
            System.out.println ("Visitor Name = " + me.getValue().getVisitorName());
            System.out.println ("Visitor Email = " + me.getValue().getVisitorEmail());
            System.out.println ("Visitor Phone = " + me.getValue().getVisitorPhone());
            System.out.println();
         }
      }
      System.out.println("------------------------------------------------");
   }
}

