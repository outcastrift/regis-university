/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

import java.util.Objects;

/**
 *
 * @author Mike
 */
public class Person {

   String firstName;
   String lastName;
   String SSN;
   String address1;
   String address2;

   public Person(String firstName, String lastName, String SSN, String address1, String address2) {
      this.firstName = firstName;
      this.lastName = lastName;
      this.SSN = SSN;
      this.address1 = address1;
      this.address2 = address2;
   }

   public String getFirstName() {
      return firstName;
   }

   public void setFirstName(String firstName) {
      this.firstName = firstName;
   }

   public String getLastName() {
      return lastName;
   }

   public void setLastName(String lastName) {
      this.lastName = lastName;
   }

   public String getSSN() {
      return SSN;
   }

   public void setSSN(String SSN) {
      this.SSN = SSN;
   }

   public String getAddress1() {
      return address1;
   }

   public void setAddress1(String address1) {
      this.address1 = address1;
   }

   public String getAddress2() {
      return address2;
   }

   public void setAddress2(String address2) {
      this.address2 = address2;
   }

   @Override
   public int hashCode() {
      int hashCode = 0;
      for (char c : this.firstName.toCharArray()){ 
         int inc = (int)(c);
         hashCode = hashCode + inc;
      }
      return  hashCode;
   }


   @Override
   public boolean equals(Object obj) {
      if (obj == null) {
         return false;
      }
      if (getClass() != obj.getClass()) {
         return false;
      }
      final Person other = (Person) obj;
      if (!Objects.equals(this.firstName, other.firstName)) {
         return false;
      }
      if (!Objects.equals(this.lastName, other.lastName)) {
         return false;
      }
      if (!Objects.equals(this.SSN, other.SSN)) {
         return false;
      }
      if (!Objects.equals(this.address1, other.address1)) {
         return false;
      }
      if (!Objects.equals(this.address2, other.address2)) {
         return false;
      }
      return true;
   }
   
   
   
}




