/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cs310.model.domain;

import java.util.Objects;

/**
 *
 * @author Mike
 */
public class Visitor {
   private String visitorName;
   private String visitorPhone;
   private String visitorEmail;

   public Visitor() {
   }

   public Visitor(String visitorName, String visitorPhone, String visitorEmail) {
      this.visitorName = visitorName;
      this.visitorPhone = visitorPhone;
      this.visitorEmail = visitorEmail;
   }

   public String getVisitorName() {
      return visitorName;
   }

   public void setVisitorName(String visitorName) {
      this.visitorName = visitorName;
   }

   public String getVisitorPhone() {
      return visitorPhone;
   }

   public void setVisitorPhone(String visitorPhone) {
      this.visitorPhone = visitorPhone;
   }

   public String getVisitorEmail() {
      return visitorEmail;
   }

   public void setVisitorEmail(String visitorEmail) {
      this.visitorEmail = visitorEmail;
   }

   @Override
   public int hashCode() {
      int hashCode = 0;
      for (char c : this.visitorPhone.toCharArray()){ 
         int inc = (int)(c - '0');
         hashCode = hashCode + inc;
      }
      return  hashCode;
   }

   @Override
   public boolean equals(Object obj) {
      if (obj == null) {
         return false;
      }
      if (getClass() != obj.getClass()) {
         return false;
      }
      final Visitor other = (Visitor) obj;
      if (!Objects.equals(this.visitorName, other.visitorName)) {
         return false;
      }
      if (!Objects.equals(this.visitorPhone, other.visitorPhone)) {
         return false;
      }
      if (!Objects.equals(this.visitorEmail, other.visitorEmail)) {
         return false;
      }
      return true;
   }
   
}
