
package com.cs310.model.domain;

/**
 * CS310Class.  This is a sample class to describe building a class and JUnit tests in NetBeans.
 * This class contains three attributes, along with various methods.
 * 
 * @author Mike Manning
 *
 */

public class CS310Class {
   private int myInteger;
   private float myFloat;
   private String myString;

   public CS310Class() {
   }

   /**
    * This constructor requires all fields to be passed as parameters.
    * In a working class, valid descriptions of the attributes are requuired.
	 * @param myInteger - this is an integer attribute.  
    * @param myFloat - this is a float attribute.
    * @param myString - this is a string attribute.
	 */
    
   public CS310Class(int myInteger, float myFloat, String myString) {
      this.myInteger = myInteger;
      this.myFloat = myFloat;
      this.myString = myString;
   }

   public String getMyString() {
      return myString;
   }

   public void setMyString(String myString) {
      this.myString = myString;
   }

   public int getMyInteger() {
      return myInteger;
   }

   public void setMyInteger(int myInteger) {
      this.myInteger = myInteger;
   }

   public float getMyFloat() {
      return myFloat;
   }

   public void setMyFloat(float myFloat) {
      this.myFloat = myFloat;
   }

   public boolean equals(CS310Class inCS310) {

      if (this.myInteger != inCS310.myInteger) {
         return false;
      }
      
      if (this.myFloat != inCS310.myFloat) {
         return false;
      }
      
      if (!(this.myString.equals(inCS310.myString))) {
         return false;
      }
      
      return true;
   }

   @Override
   public String toString() {
      return "CS310Class[" + "myInteger=" + myInteger + ", myFloat=" + myFloat + ", myString=" + myString + ']';
   }
   
   /**
	 * Validate if the instance variables are valid
	 * 
	 * @return boolean - true if instance variables of CS310Class are valid, else false
	 */
   
   public boolean validate() {
      boolean retValue = false; 
      if ((this.myFloat != 0.0) &&
         (this.myInteger != 0) &&
         (this.myString != null)) {
         retValue = true;
      }
      return retValue;
   }
   
   public boolean isGreater (float inFloat) {
      boolean retValue = false;
      if (inFloat > this.myFloat) {
         retValue = true;
      }
      return retValue;
   }
   
   public boolean isGreater (int inInteger) {
      boolean retValue = false;
      if (inInteger > this.myInteger) {
         retValue = true;
      }
      return retValue;
   }
   
    public boolean isMyStringExit () {
      boolean retValue = false;
      if (this.myString.equals ("EXIT")) {
         retValue = true;
      }
      return retValue;
   }
}
